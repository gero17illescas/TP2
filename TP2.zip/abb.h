#ifndef ABB_H
#define ABB_H

#include <stdbool.h>
#include <stddef.h>

/* Los structs deben llamarse 'abb' y 'abb_iter'. */
struct abb;
struct abb_iter;

typedef struct abb abb_t;
typedef struct abb_iter abb_iter_t;

/* Tipos de función para comparar claves y destruir datos. */
typedef int (*abb_comparar_clave_t) (const char* , const char* );
typedef void (*abb_destruir_dato_t) (void* );


/* Primitivas del mapa. */
abb_t* abb_crear(abb_comparar_clave_t cmp, abb_destruir_dato_t destruir_dato);

bool abb_guardar(abb_t* arbol, const char* clave, void* dato);

void* abb_borrar(abb_t* arbol, const char* clave);

void* abb_obtener(const abb_t* arbol, const char* clave);

bool abb_pertenece(const abb_t* arbol, const char* clave);

size_t abb_cantidad(abb_t* arbol);

void abb_destruir(abb_t* arbol);

/* Implementa el iterador interno.
   "visitar" es una función de callback que recibe la clave, el valor y un
   puntero extra, y devuelve true si se debe seguir iterando, false en caso
   contrario).
 */
void abb_in_order(abb_t* arbol, bool visitar(const char*, void*, void*), void* extra,char* inicio,char* final);

/* Primitivas del iterador externo. */
abb_iter_t* abb_iter_in_crear(const abb_t* arbol);

bool abb_iter_in_avanzar(abb_iter_t* iter);

const char* abb_iter_in_ver_actual(const abb_iter_t* iter);

bool abb_iter_in_al_final(const abb_iter_t* iter);

void abb_iter_in_destruir(abb_iter_t* iter);


abb_iter_t* crear_iter_inorder_acotado(abb_t* abb,char* inicio,char* final);
#endif // ABB_H